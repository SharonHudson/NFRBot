﻿using Microsoft.Bot.Builder.Dialogs;
using QnAMakerDialog;
using QnAMakerDialog.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace NFRBot
{
    [Serializable]
    [QnAMakerService("080cbaf948734812a455bc3acffacb15", "bab79cc7-0ea5-4d96-9253-54d53b75b61e")]
    public class QnADialog : QnAMakerDialog<object>
    {
        public override async Task NoMatchHandler(IDialogContext context, string originalQueryText)
        {
            if (string.Equals(originalQueryText, "yes", StringComparison.InvariantCultureIgnoreCase))
            {
                await context.PostAsync("Happy to help you.");
                await context.PostAsync("Bye. Looking forward to our next awesome conversation already.");
                context.Done(this);
            }
            else
            {
                await context.PostAsync($"Sorry, I could not find a relevant answer.");
            }

        }

        [QnAMakerResponseHandler(65)]
        public async Task LowScoreHandler(IDialogContext context, string originalQueryText, QnAMakerResult result)
        {
            await context.PostAsync(result.Answers.FirstOrDefault().Answer);
            await context.PostAsync($"Is this what you are looking for? If not, please try re-phrasing your question.");
            context.Wait(MessageReceived);
        }

        public override async Task DefaultMatchHandler(IDialogContext context, string originalQueryText, QnAMakerResult result)
        {
            await context.PostAsync(result.Answers.FirstOrDefault().Answer);
            context.Done(true);
        }
    }
}